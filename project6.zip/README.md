# Project-6-Build-a-turn-based-board-game
In this project, I have built a game which allow 2 player play in turn. They move around on a board size 10x10 and collect weapon. The try to attack each other till death. :D
